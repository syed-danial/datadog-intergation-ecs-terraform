from . import SpanTypes


APP = "consul"
# [TODO] Deprecated, remove when we remove AppTypes
APP_TYPE = SpanTypes.CACHE
SERVICE = "consul"

CMD = "consul.command"

KEY = "consul.key"
